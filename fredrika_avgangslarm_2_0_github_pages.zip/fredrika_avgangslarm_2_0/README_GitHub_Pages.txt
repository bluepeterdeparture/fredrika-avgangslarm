Fredrika Avgångslarm 2.0

Innehåll:
- index.html
- style.css
- app.js
- media/sounds/five-minute-tyfon.wav
- media/sounds/departure-tyfon.wav

Publicera gratis på GitHub Pages:
1. Skapa ett gratis GitHub-konto om du inte redan har ett.
2. Skapa ett nytt repository, till exempel fredrika-avgangslarm.
3. Ladda upp alla filer och mappar i denna ZIP.
4. Gå till Settings -> Pages.
5. Under Branch väljer du main och /root.
6. Tryck Save.
7. Efter någon minut får du en publik adress.

Första start:
1. Öppna appen.
2. Tryck API-nyckel och klistra in din Trafikverket API-nyckel.
3. Tryck Spara nyckel lokalt.
4. Välj färjeled. Skenäsleden är förvalt om den finns.
5. Tryck Aktivera larm.
6. Tryck Test 5 min och Test avgång.
7. Tryck Håll skärmen vaken om enheten stödjer det.

Viktigt:
- Låt sidan vara öppen på skärmen.
- Larmet bygger på att webbläsaren tillåter ljud efter att du tryckt Aktivera larm.
- Appen har inga manuella reservturlistor. Den hämtar data från Trafikverkets API.
